package com.JpetStore.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.JpetStore.utility.Reports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class UserRegistrationPage 
{
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	public UserRegistrationPage(WebDriver driver, ExtentTest test)
	{
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
		
	}
	
	private By signInLink=By.linkText("Sign In");
	private By registerNow=By.linkText("Register Now!");
	private By verifyRegistration=By.xpath("//h3[normalize-space()='User Information']");
	
	private By newUserID=By.name("username");
	private By newPassword=By.name("password");
	private By conformNewPassword=By.name("repeatedPassword");
	
	private By firstName=By.name("account.firstName");
	private By lastName =By.name("account.lastName");
	private By email=By.name("account.email");
	private By phoneNumber=By.name("account.phone");
	private By address1=By.name("account.address1");
	private By address2=By.name("account.address2");
	private By city=By.name("account.city");
	private By state=By.name("account.state");
	private By zipCode=By.name("account.zip");
	private By country=By.name("account.country");
	
	private By preferredLanguage=By.name("account.languagePreference");
	private By favouriteCategory=By.name("account.favouriteCategoryId");
	private By saveInformation=By.name("newAccount");
	
	private By userName= By.name("username");
	private By password= By.name("password");
	private By loginBtn=By.name("signon");
	private By myAccountLink=By.linkText("My Account");
	private By enterCredentialsMessage=By.xpath("//p[normalize-space()='Please enter your username and password.']");
	private By invalidCredentialsMessage=By.xpath("//li[contains(text(),'Invalid username or password.')]");
	
	private By passwordRecoveryLink =By.linkText("forgotPassword");
	
	private By signOutLink=By.linkText("Sign Out");

	public void navigateToLoginPage()
	{
		wait.until(ExpectedConditions.elementToBeClickable(signInLink)).click();
		Assert.assertTrue(driver.findElement(userName).isDisplayed(), "Login page is not visible");
		System.out.println("Navigated to login page");
	}
	
	public void clickRegisterNow()
	{
		wait.until(ExpectedConditions.elementToBeClickable(registerNow)).click();
		Assert.assertTrue(driver.findElement(verifyRegistration).isDisplayed(), "Registration page is not displayed");
		System.err.println("Registration page is opened");
	}
	
	public void enterRegistrationDetails()
	{
		driver.findElement(newUserID).sendKeys("rahul");
		driver.findElement(newPassword).sendKeys("rahul2002");
		driver.findElement(conformNewPassword).sendKeys("rahul2002");	
		
		driver.findElement(firstName).sendKeys("Rahul");
		driver.findElement(lastName).sendKeys("Chinta");
		driver.findElement(email).sendKeys("rahul@gmail.com");
		driver.findElement(phoneNumber).sendKeys("8556933214");
		driver.findElement(address1).sendKeys("2-32/23/A");
		driver.findElement(address2).sendKeys("Arya nagar");
		driver.findElement(city).sendKeys("Karimnagar");
		driver.findElement(state).sendKeys("Telangana");
		driver.findElement(zipCode).sendKeys("589998");
		driver.findElement(country).sendKeys("India");
		
		Select s1,s2;		
		s1=new Select(driver.findElement(preferredLanguage));
		s1.selectByVisibleText("english");		
		s2=new Select(driver.findElement(favouriteCategory));
		s2.selectByVisibleText("CATS");
		
		driver.findElement(saveInformation).click();		
	}
	
	public void verifyRegistration() {
	    try {
	        wait.until(ExpectedConditions.visibilityOf(driver.findElement(signInLink)));
	        Reports.generateReport(driver, test, Status.PASS, "Registration is passed ");
	        System.out.println("Registration is passed.");
	        Assert.assertTrue(driver.findElement(signInLink).isDisplayed(), "Registration verification failed.");
	    } catch (TimeoutException e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Registration is failed");
	        System.out.println("Registration is failed.");
	        Assert.fail("Registration verification failed.");
	    }
	}
	
	public void enterLoginDetails(String username,String pass)
	{
		driver.findElement(userName).sendKeys(username);
		driver.findElement(password).clear();
		driver.findElement(password).sendKeys(pass);
	    System.out.println("Entered Username and password");
		driver.findElement(loginBtn).click();
		System.out.println("Clicked on Login");
		
	}
	
	public void verifyMyAccountLink() {
	    try {
	        wait.until(ExpectedConditions.visibilityOf(driver.findElement(myAccountLink)));
	        Reports.generateReport(driver, test, Status.PASS, "Login is passed ");
	        System.out.println("Login is passed.");
	        Assert.assertTrue(driver.findElement(myAccountLink).isDisplayed(), "Login verification failed.");
	    } catch (TimeoutException e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Login is failed");
	        System.out.println("Login is failed.");
	        Assert.fail("Login verification failed.");
	    }
	}

	
	public void verifyInvalidLogin(String expectedMessage) {
	    try {
	        WebElement errorMessageElement = wait.until(ExpectedConditions.visibilityOfElementLocated(invalidCredentialsMessage));
	        String actualMessage = errorMessageElement.getText();
	        
	        System.out.println("Actual Error Message: " + actualMessage);
	        Assert.assertEquals(actualMessage, expectedMessage, "Invalid login message mismatch!");

	        Reports.generateReport(driver, test, Status.PASS, "Invalid Login Verification Passed: " + actualMessage);
	    } catch (TimeoutException e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Invalid Login Failed: Error message not displayed.");
	        System.out.println("Invalid Login Failed: Error message not displayed.");
	        Assert.fail("Error message not displayed.");
	    } catch (AssertionError e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Invalid Login Failed: Expected '" + expectedMessage + "', but got '" + e.getMessage() + "'");
	        System.out.println("Invalid Login Failed: Expected '" + expectedMessage + "', but got '" + e.getMessage() + "'");
	        Assert.fail("Invalid login message mismatch!");
	    }
	}

	
	public void verifyEmptyLogin(String expectedMessage) {
	    try {
	        WebElement errorMessageElement = wait.until(ExpectedConditions.visibilityOfElementLocated(enterCredentialsMessage));
	        String actualMessage = errorMessageElement.getText();

	        System.out.println("Actual Error Message: " + actualMessage);
	        Assert.assertEquals(actualMessage, expectedMessage, "Empty login message mismatch!");

	        Reports.generateReport(driver, test, Status.PASS, "Empty fields Login Verification Passed: " + actualMessage);
	    } catch (TimeoutException e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Empty fields Login Failed: Error message not displayed.");
	        System.out.println("Empty fields Login Failed: Error message not displayed.");
	        Assert.fail("Error message not displayed.");
	    } catch (AssertionError e) {
	        Reports.generateReport(driver, test, Status.FAIL, "Empty fields Login Failed: Expected '" + expectedMessage + "', but got '" + e.getMessage() + "'");
	        System.out.println("Empty fields Login Failed: Expected '" + expectedMessage + "', but got '" + e.getMessage() + "'");
	        Assert.fail("Empty login message mismatch!");
	    }
	}
	
	public void verifyPasswordRecoveryFeature() {
	    try {
	        WebElement recoveryElement = wait.until(ExpectedConditions.visibilityOfElementLocated(passwordRecoveryLink));
	        Assert.assertTrue(recoveryElement.isDisplayed(), "Password recovery feature is present.");

	        Reports.generateReport(driver, test, Status.PASS, "Password recovery feature is available.");
	        System.out.println("Password recovery feature is available.");
	    } catch (TimeoutException e) {
	        String screenshotPath = Reports.captureScreenshot(driver, "PasswordRecovery_Bug");
	        Reports.generateReport(driver, test, Status.FAIL, "Bug: Password recovery feature is missing");
	        
	        System.out.println("Bug: Password recovery feature is missing. Screenshot captured: " + screenshotPath);
	        //Assert.fail("Bug: Password recovery feature is missing!");
	    }
	}


	
	public void clickLogout()
	{
		//driver.findElement(signOutLink);
		wait.until(ExpectedConditions.elementToBeClickable(signOutLink)).click();
	}
	
	
}
