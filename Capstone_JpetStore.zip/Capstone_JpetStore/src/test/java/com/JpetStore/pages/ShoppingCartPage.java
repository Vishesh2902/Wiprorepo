package com.JpetStore.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.JpetStore.utility.Reports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ShoppingCartPage 
{
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	public ShoppingCartPage(WebDriver driver, ExtentTest test)
	{
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;	
	}
	
	private By updateQuantity=By.xpath("//div[2]/div[2]/div[1]//table/tbody/tr[3]/td[5]/input");
	private By removeButton=By.xpath("//div[2]/div[2]/div[1]//table/tbody/tr[3]/td[8]/a");
	private By proceedToCheckoutButton=By.linkText("Proceed to Checkout");
	private By continueButton=By.name("newOrder");
	private By confirmButton=By.linkText("Confirm");
	private By stockStatus = By.xpath("//div[2]/div[2]/div[1]//table/tbody/tr[2]/td[4][contains(text(), 'false')]");
	private boolean bugDetected = false; // Track if bug is found

	By verifyOrder=By.xpath("//li[contains(text(), 'Thank you, your order has been submitted.')]");
	
	public void updateOrderQuantity( String quantity)
	{
		 wait.until(ExpectedConditions.visibilityOfElementLocated(updateQuantity)).clear();
	     driver.findElement(updateQuantity).sendKeys(quantity);
	     Reports.generateReport(driver, test, Status.PASS, "Updated order quantity to 4.");
	     System.out.println("Updated order quantity");
	}
	
	public void removeProductFromCart()
	{
		wait.until(ExpectedConditions.elementToBeClickable(removeButton)).click();
        Reports.generateReport(driver, test, Status.PASS, "Removed product from cart.");
        System.out.println("Removed product from cart.");
	}
	
	public boolean isProductInStock() {                     //////////
	    try {
	        wait.until(ExpectedConditions.visibilityOfElementLocated(stockStatus));
	        System.out.println("Product is out of stock!");
	        Reports.generateReport(driver, test, Status.FAIL, "BUG: Product is out of stock but still allowed to order");
	        Reports.captureScreenshot(driver, "OutOfStock_Bug");
	        bugDetected =true;
	        return false;  // Product is out of stock
	    } catch (Exception e) {
	        System.out.println("Product is in stock.");
	        return true;  // No "Out of Stock" message, so it's available
	    }
	}                                                      //////////
	
	public void clickProceedToCheckout()
	{
		if (!isProductInStock()) 
		{						////////////
	        String issueMessage = "BUG: proceeded to check-out even when product is out of stock";
	        Reports.generateReport(driver, test, Status.FAIL, issueMessage);
	        System.out.println(issueMessage);
	        //Assert.fail(issueMessage); // Fail the test to highlight the bug
	    }						////////////
	    
		wait.until(ExpectedConditions.elementToBeClickable(proceedToCheckoutButton)).click();
        Reports.generateReport(driver, test, Status.PASS, "Proceeded to checkout.");
        System.out.println("Proceeded to checkout.");
	}
	
	public void clickContinueButton()
	{
		 wait.until(ExpectedConditions.elementToBeClickable(continueButton)).click();
	     Reports.generateReport(driver, test, Status.PASS, "Continued after address confirmation.");
	     System.out.println("Continued after address confirmation.");
	}
	
	public void clickConfirmButton()
	{
		 wait.until(ExpectedConditions.elementToBeClickable(confirmButton)).click();
	     Reports.generateReport(driver, test, Status.PASS, "Clicked confirm button.");
	     System.out.println("Clicked confirm button.");
	}
	
	

	
	public void verifyTheOrderPlaced()
	{
		if (bugDetected) 
		{
	        Reports.generateReport(driver, test, Status.FAIL, "BUG: Order placed even when stock is unavailable!");
	        Reports.captureScreenshot(driver, "Order palced even in out-of-stock_Bug");
	        System.out.println("BUG: Order placed even when stock is unavailable");
	        //Assert.fail("Order placed even when stock is unavailable");
	    } else
	    {
	    	try 
			{
	            Assert.assertTrue(wait.until(ExpectedConditions.visibilityOfElementLocated(verifyOrder)).isDisplayed(), "Order confirmation message not displayed!");
	            Reports.generateReport(driver, test, Status.PASS, "Verified order placed successfully.");
	            System.out.println("Order is Verified and placed successfully.");
	        } catch (Exception e) 
			{
	            Reports.generateReport(driver, test, Status.FAIL, "Order placed even when stock is unavailable!");
	            System.out.println("Order placed even when stock is unavailable!");
	            //Assert.fail("Order placed even when stock is unavailable");
	        }
		}
	}

}
