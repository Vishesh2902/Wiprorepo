package com.JpetStore.stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.JpetStore.pages.Homepage;
import com.JpetStore.pages.ProductDetailsPage;
import com.JpetStore.pages.ShoppingCartPage;
import com.JpetStore.pages.UserRegistrationPage;
import com.JpetStore.utility.Base;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ShoppingCart 
{
	WebDriver driver = Base.driver;
	ExtentTest test = Hooks.test;
	ProductDetailsPage productpage =new ProductDetailsPage(driver, test);
	Homepage homepage=new Homepage(driver, test);
	UserRegistrationPage registerpage=new UserRegistrationPage(driver, test);
	ShoppingCartPage cartpage=new ShoppingCartPage(driver, test);
	
	@Given("I enter the store and sign in")
	public void i_enter_the_store_and_sign_in() 
	{
		homepage.clickEnterToTheStoreLink();
		System.out.println("On the homepage");
		registerpage.navigateToLoginPage();
		registerpage.enterLoginDetails("kamal2002", "kamses2002");
	}

	@When("I choose a pet {string}")
	public void i_choose_a_pet(String pet) 
	{
	    productpage.selectPetCategory(pet);
	}

	@And("I select a product {string}, item {string} and add it to the cart")
	public void i_select_a_product_item_and_add_it_to_the_cart(String product, String item) 
	{
	    productpage.selectProduct(product);
	    productpage.selectItem(item);
	    productpage.addToCart();
	}

	@And("I return to the main menu and select another pet {string}")
	public void i_return_to_the_main_menu_and_select_another_pet(String pet) 
	{
	    productpage.returnToMainMenu();
	    productpage.selectPetCategory(pet);
	}

	@And("I select another product {string}, item {string} and add it to the cart")
	public void i_select_another_product_item_and_add_it_to_the_cart(String product, String item) 
	{
		productpage.selectProduct(product);
	    productpage.selectItem(item);
	    productpage.addToCart();
	}

	@And("I update the quantity of one product {string}")
	public void i_update_the_quantity_of_one_product(String quantity) 
	{
	    cartpage.updateOrderQuantity(quantity);
	}
	
	@And("I remove one product from the cart")
	public void i_remove_one_product_from_the_cart() 
	{
	    cartpage.removeProductFromCart();
	}


	@And("I proceed to checkout")
	public void i_proceed_to_checkout() 
	{
	    cartpage.clickProceedToCheckout();
	}

	@And("I continue after address confirmation")
	public void i_continue_after_address_confirmation() 
	{
	    cartpage.clickContinueButton();
	}

	@Then("I confirm and verify the order")
	public void i_confirm_and_verify_the_order() 
	{
	    cartpage.clickConfirmButton();
	    cartpage.verifyTheOrderPlaced();
	}

}

