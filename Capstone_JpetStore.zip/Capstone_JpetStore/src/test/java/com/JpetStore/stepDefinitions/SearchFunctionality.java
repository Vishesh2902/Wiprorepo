package com.JpetStore.stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.JpetStore.pages.Homepage;
import com.JpetStore.pages.SearchFunctionalityPage;
import com.JpetStore.utility.Base;
import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchFunctionality 
{
	WebDriver driver = Base.driver;
	ExtentTest test = Hooks.test;
	SearchFunctionalityPage searchpage =new SearchFunctionalityPage(driver, test);
	Homepage homepage=new Homepage(driver, test);
	
	@Given("I am on the JPetStore home page")
	public void i_am_on_the_j_pet_store_home_page() 
	{
		homepage.clickEnterToTheStoreLink();
		searchpage.verifyPetHomePage();
		System.out.println("On the homepage");
	}

	@When("I search for {string}")
	public void i_search_for(String keyword) 
	{
	    searchpage.enterSearchKeyword(keyword);
	    searchpage.clickSearchButton();
	}

	@Then("I should see search results related to pet")
	public void i_should_see_search_results_related_to_pet() 
	{
	    searchpage.verifySearchResults();
	}

	@And("I select a pet from searched result")
	public void i_select_a_pet_from_searched_result() 
	{
	    searchpage.selectThePetFromSearch();
	    System.out.println("Pet is selected");
	}

	@And("I get the price and description")
	public void i_get_the_price_and_description() 
	{
		 System.out.println("Displaying product details:");
	     searchpage.getDescription();
	     searchpage.getPriceDetails();
	}

	@Then("I add the product to cart")
	public void i_add_the_product_to_cart() 
	{
		 searchpage.addToCartFromSearch();
	}

}
